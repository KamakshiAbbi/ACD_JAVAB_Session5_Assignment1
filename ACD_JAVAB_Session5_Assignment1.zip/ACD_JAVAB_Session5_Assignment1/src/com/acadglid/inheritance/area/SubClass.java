//Session5_Assignment1 : 14.5.2016
//Author: Kamakshi Abbi
package com.acadglid.inheritance.area;
import java.util.Scanner;

public class SubClass extends SuperClass{
	int recLength, recBreadth; 
	double triHieght, triBreadth;
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		SubClass sc = new SubClass();
		System.out.println("Enter the length for rectangle");
		sc.recLength = input.nextInt();
		System.out.println("Enter the breadth for rectangle");
		sc.recBreadth = input.nextInt();
		
		//Calling superclass method/properties via sub class object
		sc.area = sc.area(sc.recLength,sc.recBreadth);
		System.out.println("The area of rectangle is :" + sc.area);
		
		System.out.println("Enter the hiegth for triangle");
		sc.triHieght = input.nextDouble();
		System.out.println("Enter the breadth for triangle");
		sc.triBreadth = input.nextDouble();
		
		//Calling superclass method/properties via sub class object
		sc.area = sc.area(sc.triBreadth,sc.triHieght);
		System.out.println("The area of triangle is :" + sc.area);
		input.close();
		
		
	}

}
