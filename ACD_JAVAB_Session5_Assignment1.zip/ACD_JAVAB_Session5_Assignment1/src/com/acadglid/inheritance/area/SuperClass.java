//Session5_Assignment1 : 14.5.2016
//Author: Kamakshi Abbi
package com.acadglid.inheritance.area;

public class SuperClass {
	double area;
	public double area(int l , int b){
		area = l*b;
		return area;
	}
	public double area(double b,double h){
		area = 0.5 * b * h;
		return area;
	}

}
